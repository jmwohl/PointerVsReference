#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){

    
    string* myNum;
    cout << myNum << endl;
    
    string ten = "10";
    cout << ten << endl;
    cout << &ten << endl;
    
    myNum = &ten;
    cout << myNum << endl;
    cout << *myNum << endl;
    
    ten = "20";
    
    cout << myNum << endl;
    cout << *myNum << endl;
    
    ten.length();
    
    //  like *myNum.length();
    cout << myNum->length() << endl;
    
    changeString(ten);
    
    changeString(&ten);
    
    
}

//--------------------------------------------------------------
void testApp::update(){

}

void testApp::changeString(string &strRef) {
    strRef = "CHANGED";
    cout << strRef.length() << endl;
}

void testApp::changeString(string *strRef) {
    *strRef = "CHANGED";
    cout << strRef->length() << endl;
}

//--------------------------------------------------------------
void testApp::draw(){

}

//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}
